

#include "Matriz2D-2.h"

#include <iostream>
using namespace std;


// Constructor sin argumentos (matriz vacia)
Matriz2D_2 :: Matriz2D_2(void)
	: filas(0), columnas(0), datos(0) 
{
}

// Constructor de matrices cuadradas
Matriz2D_2 :: Matriz2D_2(int orden)	
	: filas(orden), columnas(orden) 
{
	PedirMemoria (filas, columnas);
}

// Constructor de matrices rectangulares, 
// con iniciacion a un valor dado (opcional)
Matriz2D_2 :: Matriz2D_2(int fils, int cols, TipoBase valor) 
	: filas(fils),columnas(cols) 
{
	PedirMemoria (filas, columnas);
	Inicializar(valor);
}

// Destructor
Matriz2D_2 :: ~Matriz2D_2(void) 
{
	LiberarMemoria();
}

// Consulta si la matriz esta vacia
bool Matriz2D_2 :: EstaVacia(void) 
{
	return (datos == 0);
}

// M�todo de lectura de las filas 
int Matriz2D_2 :: NumFilas (void)
{
	return (filas);
}

// M�todo de lectura de las columnas
int Matriz2D_2 :: NumColumnas (void)
{
	return (columnas);
}

// Metodo de escritura
// PRE: 0 <= fila < NumFilas()
// PRE: 0 <= col  < NumColumnas()
void Matriz2D_2 :: PonValor(int fila, int col, TipoBase valor)  
{
	if ((fila < filas) && (col < columnas)) 
		datos[fila][col] = valor;
}

// Metodo de lectura
// PRE: 0 <= fila < NumFilas()
// PRE: 0 <= col  < NumColumnas()
TipoBase Matriz2D_2 :: LeeValor(int fila, int col) 
{
	TipoBase valor;

	if ((fila < filas) && (col < columnas))
		valor = datos[fila][col];

	return (valor);
}

// Fijar todas las casillas a un valor dado  
void Matriz2D_2 :: Inicializar(TipoBase valor) 
{
	for(int i = 0; i < filas; i++)
		for(int j = 0; j < columnas; j++)
			datos[i][j] = valor;	
}	



#################################################################################################

//**********************************************
// METODOS PRIVADOS
//**********************************************
		
// Pedir memoria para alojar "fils"x"cols" datos
void Matriz2D_2 :: ReservarMemoria (int fils, int cols)
{
	// Reservar memoria
	datos = new TipoBase * [filas];
	datos[0] = new TipoBase[filas * columnas];

	// Iniciar los punteros que apuntan al principio 
	// de cada fila
	for(int i = 1; i < filas; i++)
		datos[i] = datos[i - 1] + columnas;
}




// Liberar la memoria ocupada
void Matriz2D_2 :: LiberarMemoria (void)
{
	if (datos) {
		delete [] datos[0];
		delete [] datos;
	}
}







