

#ifndef MATRIZ2D2
#define MATRIZ2D2

// Definici�n del tipo TipoBase y el valor NULO asociado
typedef int TipoBase;
#define NULO 0
	
///////////////////////////////////////////////////////////////

class Matriz2D_2 {

	private:
		TipoBase ** datos;	// Los valores de la matriz
		int filas;			// N�m. de filas
		int columnas;		// N�m. de columnas

	public:
		// Constructor sin argumentos (matriz vacia)
		Matriz2D_2(void);       

		// Constructor de matrices cuadradas
		Matriz2D_2(int orden);  
		
		// Constructor de matrices rectangulares, 
		// con iniciacion a un valor dado (opcional)
		Matriz2D_2(int fils, int cols, TipoBase valor=NULO);

		// Destructor
		~Matriz2D_2(void); 
		
		// Consulta si la matriz esta vacia
		bool EstaVacia(void); 
 
		// M�todos de lectura de las filas y columnas
		int NumFilas (void);
		int NumColumnas (void);

		// M�todo de lectura / escritura
		// PRE: 0 <= fila < NumFilas()
		// PRE: 0 <= col  < NumColumnas()
		TipoBase LeeValor(int fila, int col);
		void	 PonValor(int fila, int col, TipoBase valor); 

		// Fijar todas las casillas a un valor dado  
		void Inicializar (TipoBase valor=NULO);

	private:
	
		// Pedir memoria para alojar "fils"x"cols" datos
		void PedirMemoria (int fils, int cols);

		// Liberar la memoria ocupada
		void LiberarMemoria (void);
};

///////////////////////////////////////////////////////////////
		
#endif
