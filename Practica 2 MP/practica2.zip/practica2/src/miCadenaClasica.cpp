#include <iostream>
#include "miCadenaClasica.h"

using namespace std;

//EJERCICIO 9
int longitud_cadena(const char *cadena){
	const char *p;
	for(p=cadena; *p != '\0'; p++);
	return(p-cadena);
}

//EJERCICIO 10
bool palindromo_rec (const char *cadena, int izda, int dcha){
	if (izda >= dcha) return (true);
	if (*(cadena+izda)==' ') return palindromo_rec (cadena, izda+1, dcha);
	if (*(cadena+dcha)==' ') return palindromo_rec (cadena, izda, dcha-1);
	if (toupper(*(cadena+izda)) == toupper(*(cadena+dcha))) return palindromo_rec (cadena, izda+1, dcha-1);
	else
	return(false);
}

//EJERCICIO 11
int compara_cadenas(const char *cad1, const char *cad2){
	const char *p1, *p2;

	for(p1=cad1; *p1 != '\0'; p1++);
	for(p2=cad2; *p2 != '\0'; p2++);
	
	return((p1-cad1)-(p2-cad2));		
}

//EJERCICIO 12
char copiar_cadena(char *cad1, const char *cad2){
	char *p1 = cad1;
	for(const char *p2 = cad2; *p2 != '\0'; p2++){
		*p1 = *p2;
		p1++;
	}
	return *(cad1 = p1);
}

//EJERCICIO 13
char encadenar_cadena(char *cad1, const char *cad2){
	char *p1;
	const char *p2=cad2;

	for(p1 = cad1; *p1 != '\0'; p1++);

	while(*p2 != '\0'){
	*p1=*p2;
	p1++;
	p2++;
	}
	
	return *(cad1 = p1);

}

//EJERCICIO 14
char subcadena(char *cad1, const char *cad2, int inicio, int longitud){
	
	for(const char *p2=cad2+inicio; longitud != 0; longitud--){
		*cad1=*p2;
		cad1++;
		p2++;
	}

	return *cad1;
}

//EJERCICIO 15
void invertir_cadena(char *cad1, const char *cad2){
	int lon = 0;
	while(*(cad2+lon++)!='\0');
	lon--;
	for(int i = 0; i < lon; i++){
		*(cad1+i) = *(cad2 + lon - i - 1);
	}
	*(cad1+lon)='\0';
}


